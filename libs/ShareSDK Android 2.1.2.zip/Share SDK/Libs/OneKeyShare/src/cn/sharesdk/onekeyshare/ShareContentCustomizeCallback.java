package cn.sharesdk.onekeyshare;

import cn.sharesdk.framework.Platform;

public interface ShareContentCustomizeCallback {

	public void onShare(Platform platform, Platform.ShareParams paramsToShare);

}
