package com.loopj.android.http.sample;

import android.app.Activity;

public class BinarySample extends Activity {

}
